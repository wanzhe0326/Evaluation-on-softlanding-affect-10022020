function [ NCsigma_xx,NCsigma_yy,NCsigma_xy,aNCsigma_xxnew1,aNCsigma_xxnew2,aNCsigma_yynew1,aNCsigma_yynew2,aNCsigma_xynew1,aNCsigma_xxnew3,aNCsigma_yynew3,aNCsigma_xynew2,aNCsigma_xynew3]=ForceElastic(j1up,j1down,j2up,j2down,nx,NCsigma_xx,NCsigma_yy,NCsigma_xy,Coeff_32,Coeff_34,Coeff_36,Coeff_38,Coeff_39,Coeff_310,NCv11,NCv12,FourthOrder,tt,aNCsigma_xxnew1,aNCsigma_xxnew2,aNCsigma_yynew1,aNCsigma_yynew2,aNCsigma_xynew1,aNCsigma_xxnew3,aNCsigma_yynew3,aNCsigma_xynew2,aNCsigma_xynew3)
%----------------------------------------------------------------------------------------------------------------------------------------------------------------

 j=j1up:1:j1down  ;         
 i=1:(-1+nx):nx ; 

DNCv111 = NCv11(i+1,j) - NCv11(i,j);
DNCv121 = NCv12(i,j) - NCv12(i,j-1);

switch(tt)
    
    case 1
        
    a=2;
    b=-j1up+j1down+1;
    
        aNCsigma_xxnew1=zeros(a,b);
        aNCsigma_yynew1=zeros(a,b);

end

       aNCsigma_xxold1 = aNCsigma_xxnew1;
       aNCsigma_yyold1 = aNCsigma_yynew1;

 
       aNCsigma_xxnew1 =( Coeff_32 * ( DNCv111 )  +   Coeff_36 *( DNCv121 )  );
       aNCsigma_yynew1 =( Coeff_34 * ( DNCv121 )  +  Coeff_38 *( DNCv111  ) );


         NCsigma_xx(i,j) = NCsigma_xx(i,j) + 3/2 * aNCsigma_xxnew1 -1/2 * aNCsigma_xxold1 ;                                                                                
         
         NCsigma_yy(i,j) = NCsigma_yy(i,j) + 3/2 * aNCsigma_yynew1 -1/2 * aNCsigma_yyold1 ;                                 

 
        
    j=j1up:(-j1up+j1down):j1down  ;      
    i=2:1:(nx-1)  ; 
 
DNCv111 = NCv11(i+1,j) - NCv11(i,j);
DNCv121 = NCv12(i,j) - NCv12(i,j-1);

 
 switch(tt)
      
    case 1
        
        a=nx-2;
        b=2;
        
        aNCsigma_xxnew2=zeros(a,b);
        aNCsigma_yynew2=zeros(a,b);

 end
 
       aNCsigma_xxold2 = aNCsigma_xxnew2;
       aNCsigma_yyold2 = aNCsigma_yynew2;

 
       aNCsigma_xxnew2 =( Coeff_32 * ( DNCv111 )  +   Coeff_36 *( DNCv121 )  );
       aNCsigma_yynew2 =( Coeff_34 * ( DNCv121 )  +  Coeff_38 *( DNCv111  ) );
     
        NCsigma_xx(i,j) = NCsigma_xx(i,j) + 3/2 * aNCsigma_xxnew2 -1/2 * aNCsigma_xxold2 ;                                                                                
        
        NCsigma_yy(i,j) = NCsigma_yy(i,j) + 3/2 * aNCsigma_yynew2 -1/2 * aNCsigma_yyold2 ;                                 

                                       
        
%4444444444444444444444444444444444444444444444444444444444    

    j=(j1up+1):1:(j1down-1);      
    i=2:1:(nx-1)  ; 
    
switch(FourthOrder)
    
    case 1 
        
DNCv111 =( 27* ( NCv11(i+1,j) - NCv11(i,j)) - (( NCv11(i+2,j) - NCv11(i-1,j)) ))/24 ;
DNCv121 = ( 27* ( NCv12(i,j) - NCv12(i,j-1) ) - ( ( NCv12(i,j+1) - NCv12(i,j-2) ) ))/ 24 ;

    case 0
        
DNCv111 = NCv11(i+1,j) - NCv11(i,j);
DNCv121 = NCv12(i,j) - NCv12(i,j-1);

end

 
 switch(tt)
      
    case 1
        
        a=nx-2;
        b=-(j1up+1)+(j1down-1)+1;
        
        aNCsigma_xxnew3=zeros(a,b);
        aNCsigma_yynew3=zeros(a,b);

 end
       aNCsigma_xxold3 = aNCsigma_xxnew3;
       aNCsigma_yyold3 = aNCsigma_yynew3;

       aNCsigma_xxnew3=( Coeff_32 * ( DNCv111 )  +   Coeff_36 *( DNCv121 ) );
       aNCsigma_yynew3=( Coeff_34 * ( DNCv121 ) +  Coeff_38 *( DNCv111  ) );

     
        NCsigma_xx(i,j) = NCsigma_xx(i,j) + 3/2 *  aNCsigma_xxnew3 -1/2 *  aNCsigma_xxold3 ;                                                                                
                
        NCsigma_yy(i,j) = NCsigma_yy(i,j) + 3/2 *  aNCsigma_yynew3 -1/2 * aNCsigma_yyold3 ;
                                     
             
 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%       
    
 j=j2up:1:j2down ; 
 i=2:(nx-2):nx;
 
 DNCv112 = NCv11(i,j) - NCv11(i,j-1);
 DNCv122 = NCv12(i,j-1)-NCv12(i-1,j-1);      
 
switch(tt)
      
    case 1
     a=2;
     b=-j2up+j2down+1;
     
        aNCsigma_xynew1=zeros(a,b);
        
end 
        aNCsigma_xyold1=aNCsigma_xynew1;
        
        aNCsigma_xynew1=( Coeff_310 *( DNCv112 )  + Coeff_39 * ( DNCv122 ) );
 
        NCsigma_xy(i,j) = NCsigma_xy(i,j) +  3/2 * aNCsigma_xynew1 - 1/2 * aNCsigma_xyold1 ;

        
 j=j2up:(-j2up+j2down):j2down ; 
 i=3:(nx-1);
 
 DNCv112 = NCv11(i,j) - NCv11(i,j-1);
 DNCv122 = NCv12(i,j-1)-NCv12(i-1,j-1);      
 
switch(tt)
      
    case 1
     a=nx-3;
     b=2;

        aNCsigma_xynew2=zeros(a,b);
        
end 
        aNCsigma_xyold2=aNCsigma_xynew2;
        
        aNCsigma_xynew2=( Coeff_310 *( DNCv112 )  + Coeff_39 * ( DNCv122 ) );
 
        NCsigma_xy(i,j) = NCsigma_xy(i,j) +  3/2 * aNCsigma_xynew2 - 1/2 * aNCsigma_xyold2 ;
        
%4444444444444444444444444444444444444444444444444444444444        

 j=(j2up+1):1:(j2down-1) ; 
 i=3:(nx-1);
 
 switch(FourthOrder)
    
    case 1 
        
 DNCv112 = ( 27* ( NCv11(i,j) - NCv11(i,j-1) ) - ( ( NCv11(i,j+1) - NCv11(i,j-2) ) ) ) /24 ;
 DNCv122 = ( 27 * ( NCv12(i,j-1)-NCv12(i-1,j-1) ) - ( NCv12(i+1,j-1)-NCv12(i-2,j-1) ) )/24; 
 
    case 0 
        
 DNCv112 = NCv11(i,j) - NCv11(i,j-1);
 DNCv122 = NCv12(i,j-1)-NCv12(i-1,j-1);  
 
 end
 
switch(tt)
      
    case 1
     a=nx-3;
     b=-((j2up+1))+((j2down-1))+1;
     
        aNCsigma_xynew3=zeros(a,b);
        
end 
        aNCsigma_xyold3=aNCsigma_xynew3;
        
        aNCsigma_xynew3=( Coeff_310 *( DNCv112 )  + Coeff_39 * ( DNCv122 ) );
 
        NCsigma_xy(i,j) = NCsigma_xy(i,j) +  3/2 * aNCsigma_xynew3 - 1/2 * aNCsigma_xyold3 ;
