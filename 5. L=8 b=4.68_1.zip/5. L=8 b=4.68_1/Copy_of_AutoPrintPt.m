


% result1=zeros(1,800); % 501 is 500 number 1 zero initial value
% result2=zeros(1,800);
% result3=zeros(1,800); % 501 is 500 number 1 zero initial value
% result4=zeros(1,800);
% result5=zeros(1,800); % 501 is 500 number 1 zero initial value
% result6=zeros(1,800);
% result7=zeros(1,800);
% result8=zeros(1,800);

% res=zeros(1,500);
% 6m equal to 
% jj=100;
jj=0;
for ii=1:1:400
              
      file=[num2str(ii),'-Noncrack.mat'];
      
      load(file)

     
      result111(1,ii-jj)=sigma_yy(440,5);
      result222(1,ii-jj)=sigma_yy(440,7);
      result333(1,ii-jj)=sigma_yy(440,10);
      result4(1,ii-jj)=p(440,5);
      result555(1,ii-jj)=p(490,5);
       result666(1,ii-jj)=p(540,5); 
       result777(1,ii-jj)=p(590,5);
      
%       result555(1,ii-jj)=p(440,7);
%       result666(1,ii-jj)=p(440,10);
%       result777(1,ii-jj)=sigma_yy(440,1);

%       result111(1,ii-jj)=sigma_yy(541,5);
%       result222(1,ii-jj)=sigma_yy(541,7);
%       result333(1,ii-jj)=sigma_yy(541,10);
%       result444(1,ii-jj)=p(541,5);
%       result555(1,ii-jj)=p(541,7);
%       result666(1,ii-jj)=p(541,10);
%       result777(1,ii-jj)=sigma_yy(441,1);

end
