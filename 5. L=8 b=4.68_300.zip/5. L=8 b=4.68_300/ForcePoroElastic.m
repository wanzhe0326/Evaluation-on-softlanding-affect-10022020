function [ NCsigma_xx,NCsigma_yy,NCsigma_xy,NCp,aNCsigma_xxnew1,aNCsigma_xxnew2,aNCsigma_yynew1,aNCsigma_yynew2,aNCpnew1,aNCpnew2,aNCsigma_xynew1,aNCsigma_xxnew3,aNCsigma_yynew3,aNCpnew3,aNCsigma_xynew2,aNCsigma_xynew3]=ForcePoroElastic(j1up,j1down,j2up,j2down,nx,NCsigma_xx,NCsigma_yy,NCsigma_xy,NCp,Coeff_41,Coeff_42,Coeff_45,Coeff_46,Coeff_47,Coeff_48,Coeff_49,Coeff_410,Coeff_413,Coeff_414,Coeff_43,Coeff_44,NCv11,NCv12,NCv21,NCv22,UpperP,lowerP,FourthOrder,tt,aNCsigma_xxnew1,aNCsigma_yynew1,aNCpnew1,aNCsigma_xynew1,aNCsigma_xxnew2,aNCsigma_xxnew3,aNCsigma_yynew2,aNCsigma_yynew3,aNCpnew2,aNCpnew3,aNCsigma_xynew2,aNCsigma_xynew3)
%----------------------------------------------------------------------------------------------------------------------------------------------------------------
% 5.2 Lower Poroelastic layer
%ALL CHECKED

 j=j1up:j1down ;     % sigma_xx and sigma_yy are known at top        
 i=1:(-1+nx):nx  ;
 
DNCv111 = NCv11(i+1,j) - NCv11(i,j);
DNCv121 = NCv12(i,j) - NCv12(i,j-1);

DNCv21=NCv21(i+1,j) - NCv21(i,j);
DNCv22=NCv22(i,j) - NCv22(i,j-1);


switch(tt)
    
      
    case 1
        
        a=2;
        b=-j1up+j1down+1; 
    
        aNCsigma_xxnew1=zeros(a,b);
        aNCsigma_yynew1=zeros(a,b);
        aNCpnew1=zeros(a,b);
end

       aNCsigma_rrold1 = aNCsigma_xxnew1;
       aNCsigma_zzold1 = aNCsigma_yynew1;
       aNCpold1 = aNCpnew1;
       
 aNCsigma_xxnew1=( Coeff_45 * ( DNCv111 ) + Coeff_43 * ( DNCv21 )  +  Coeff_48*( DNCv121 ) + Coeff_44 * ( DNCv22 ) );
 aNCsigma_yynew1=( Coeff_46 * ( DNCv121 ) + Coeff_44 * ( DNCv22 ) +  Coeff_47 *( DNCv111 ) + Coeff_43* ( DNCv21 ) );
 aNCpnew1       =( Coeff_43 * ( DNCv111 )  + Coeff_41 * ( DNCv21 ) + Coeff_44 *( DNCv121 )+ Coeff_42*( DNCv22 )  );
           
       
        NCsigma_xx(i,j) = NCsigma_xx(i,j) + 3/2 * aNCsigma_xxnew1  - 1/2 * aNCsigma_rrold1 ;       
        
        NCsigma_yy(i,j) = NCsigma_yy(i,j) + 3/2 * aNCsigma_yynew1  - 1/2 * aNCsigma_zzold1  ;
      
        NCp(i,j)= NCp(i,j) - 3/2 * aNCpnew1 + 1/2*aNCpold1 ;
      
  %%%%%%Continue from now on;     
                     
    j=j1up:(-j1up+j1down):j1down ;   
    i=2:1:(nx-1)  ;   
 
 DNCv111 = NCv11(i+1,j) - NCv11(i,j);
 DNCv121 = NCv12(i,j) - NCv12(i,j-1);
 DNCv21 = NCv21(i+1,j) - NCv21(i,j);
 DNCv22 = NCv22(i,j) - NCv22(i,j-1);
    
switch(tt)
      
    case 1
        
       a=nx-2;
       b=2; 
       
        aNCsigma_xxnew2=zeros(a,b);
        aNCsigma_yynew2=zeros(a,b);
        aNCpnew2=zeros(a,b);
end
 
       aNCsigma_rrold2 = aNCsigma_xxnew2;
       aNCsigma_zzold2 = aNCsigma_yynew2;
       aNCpold2 = aNCpnew2;
 
 aNCsigma_xxnew2 =( Coeff_45 * ( DNCv111 ) + Coeff_43 * ( DNCv21 )  +  Coeff_48*( DNCv121 ) + Coeff_44 * ( DNCv22 ) );
 aNCsigma_yynew2 =(  Coeff_46 * ( DNCv121 ) + Coeff_44 * ( DNCv22 ) +  Coeff_47 *( DNCv111 ) + Coeff_43* ( DNCv21 ) );
 aNCpnew2 = ( Coeff_43 * ( DNCv111 )  + Coeff_41 * ( DNCv21 ) + Coeff_44 *( DNCv121 )+ Coeff_42*( DNCv22 )   );   
 
        NCsigma_xx(i,j) = NCsigma_xx(i,j) + 3/2 * aNCsigma_xxnew2  - 1/2 * aNCsigma_rrold2 ;       
        
        NCsigma_yy(i,j) = NCsigma_yy(i,j) + 3/2 * aNCsigma_yynew2  - 1/2 * aNCsigma_zzold2  ;
 
        NCp(i,j)= NCp(i,j) - 3/2 * aNCpnew2 + 1/2*aNCpold2 ;    
        
        
%444444444444444444444444444444444444444444

    j=(j1up+1):(j1down-1) ;   
    i=2:1:(nx-1)  ;   
 switch(FourthOrder)
    
    case 1
 DNCv111 = ( 27* ( NCv11(i+1,j) - NCv11(i,j) ) - ( ( NCv11(i+2,j) - NCv11(i-1,j) ) ) )/24;
 DNCv121 = (27* ( NCv12(i,j) - NCv12(i,j-1) ) - ( NCv12(i,j+1) - NCv12(i,j-2) ) )/24;
 DNCv21=( 27* ( NCv21(i+1,j) - NCv21(i,j) ) - ( NCv21(i+2,j) - NCv21(i-1,j) ) ) / 24;
 DNCv22=( 27* (  NCv22(i,j) - NCv22(i,j-1) ) - (  NCv22(i,j+1) - NCv22(i,j-2) ) )/24;        
    case 0
 DNCv111 = NCv11(i+1,j) - NCv11(i,j);
 DNCv121 = NCv12(i,j) - NCv12(i,j-1);
 DNCv21=NCv21(i+1,j) - NCv21(i,j);
 DNCv22=NCv22(i,j) - NCv22(i,j-1);
 end   
  
switch(tt)
      
    case 1
        
        a=nx-2;
        b=-(j1up+1)+(j1down-1)+1;
        
        aNCsigma_xxnew3=zeros(a,b);
        aNCsigma_yynew3=zeros(a,b);
        aNCpnew3=zeros(a,b);
end
 
       aNCsigma_rrold3 = aNCsigma_xxnew3;
       aNCsigma_zzold3 = aNCsigma_yynew3;
       aNCpold3 = aNCpnew3;
 
 aNCsigma_xxnew3 =( Coeff_45 * ( DNCv111 ) + Coeff_43 * ( DNCv21 )  +  Coeff_48*( DNCv121 ) + Coeff_44 * ( DNCv22 ) );
 aNCsigma_yynew3 =(  Coeff_46 * ( DNCv121 ) + Coeff_44 * ( DNCv22 ) +  Coeff_47 *( DNCv111 ) + Coeff_43* ( DNCv21 ) );
 aNCpnew3 = ( Coeff_43 * ( DNCv111 )  + Coeff_41 * ( DNCv21 ) + Coeff_44 *( DNCv121 )+ Coeff_42*( DNCv22 )  );   
 
        NCsigma_xx(i,j) = NCsigma_xx(i,j) + 3/2 * aNCsigma_xxnew3  - 1/2 * aNCsigma_rrold3 ;       
        
        NCsigma_yy(i,j) = NCsigma_yy(i,j) + 3/2 * aNCsigma_yynew3  - 1/2 * aNCsigma_zzold3  ;
 
        NCp(i,j)= NCp(i,j) - 3/2 * aNCpnew3 + 1/2*aNCpold3 ;         
                               
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

            
  j=j2up:j2down ;     % sigma_xy are known at top and bottom        
  i=2:(nx-2):nx ;   % sigma_xy are knwn at both sides 
  
 DNCv112 = NCv11(i,j) - NCv11(i,j-1);
 DNCv122 = NCv12(i,j-1)-NCv12(i-1,j-1);
  
switch(tt)
      
    case 1
        
    a=2;
    b=-j2up+j2down+1;
    
        aNCsigma_xynew1=zeros(a,b);

end  
        aNCsigma_rzold1=aNCsigma_xynew1;
        
        aNCsigma_xynew1 =(  Coeff_49*( DNCv112 )  + Coeff_410*( DNCv122 ) );
  
        NCsigma_xy(i,j) = NCsigma_xy(i,j) + 3/2 * aNCsigma_xynew1 -1/2 * aNCsigma_rzold1 ;
        
        
  j=j2up:-j2up+j2down:j2down ;     % sigma_xy are known at top and bottom        
  i=3:1:(nx-1) ;   % sigma_xy are knwn at both sides 
  
 DNCv112 = NCv11(i,j) - NCv11(i,j-1);
 DNCv122 = NCv12(i,j-1)-NCv12(i-1,j-1);
  
switch(tt)
      
    case 1
        
    a=nx-3;
    b=2;
        aNCsigma_xynew2=zeros(a,b);

end  
        aNCsigma_rzold2=aNCsigma_xynew2;
        
        aNCsigma_xynew2 =(  Coeff_49*( DNCv112 )  + Coeff_410*( DNCv122 ) );
  
        NCsigma_xy(i,j) = NCsigma_xy(i,j) + 3/2 * aNCsigma_xynew2 -1/2 * aNCsigma_rzold2 ;      
        
 %44444444444444444444444444444444444444444444444444       
        
  j=(j2up+1):(j2down-1) ;     % sigma_xy are known at top and bottom        
  i=3:1:(nx-1) ;   % sigma_xy are knwn at both sides 
switch(FourthOrder)
    
    case 1
 DNCv112 = (27* ( NCv11(i,j) - NCv11(i,j-1) ) - ( ( NCv11(i,j+1) - NCv11(i,j-2) ) ))/24 ;
 DNCv122 = ( 27 *( NCv12(i,j-1)-NCv12(i-1,j-1) ) - ( NCv12(i+1,j-1)-NCv12(i-2,j-1) ))/24 ;        
    case 0
 DNCv112 = NCv11(i,j) - NCv11(i,j-1);
 DNCv122 = NCv12(i,j-1)-NCv12(i-1,j-1);
end
switch(tt)
      
    case 1
        
     a=nx-3;
     b=-(j2up+1)+(j2down-1)+1;
     
        aNCsigma_xynew3=zeros(a,b);

end  
        aNCsigma_rzold3=aNCsigma_xynew3;
        
        aNCsigma_xynew3 =(  Coeff_49*( DNCv112 )  + Coeff_410*( DNCv122 ) );
  
        NCsigma_xy(i,j) = NCsigma_xy(i,j) + 3/2 * aNCsigma_xynew3 -1/2 * aNCsigma_rzold3 ;   
        
        
        

 % % % % % % % % % % % % % % % %        
%  Calculate P at interfaces % %       
% % % % % % % % % % % % % % % %
%back calculate p based on current time step no need to use former step! 

switch(UpperP)
    
    case 1
        
j=( j1up - 1 );
i=1; 

        NCp(i,j)=NCp(i,j+1)+ Coeff_413*( NCsigma_xy(i+1,j+1)- NCsigma_xy(i,j+1) ) + Coeff_414*( NCsigma_yy(i,j+1)- NCsigma_yy(i,j) ) ;
        

i=2:1:(nx)  ; 

        NCp(i,j)=NCp(i,j+1)+ Coeff_413*( NCsigma_xy(i+1,j+1)- NCsigma_xy(i,j+1) ) + Coeff_414*( NCsigma_yy(i,j+1)- NCsigma_yy(i,j) ) ;
end

switch(lowerP)
    
    case 1
        
j=( j1down );
i=1; 

        NCp(i,j+1)=NCp(i,j)-( Coeff_413*( NCsigma_xy(i+1,j+1)- NCsigma_xy(i,j+1) ) + Coeff_414*( NCsigma_yy(i,j+1)- NCsigma_yy(i,j) ) ) ;

% j=(MLT/dz+1);

i=2:1:(nx)  ; 

        NCp(i,j+1)=NCp(i,j)-( Coeff_413*( NCsigma_xy(i+1,j+1)- NCsigma_xy(i,j+1) ) + Coeff_414*( NCsigma_yy(i,j+1)- NCsigma_yy(i,j) ) ); 

end     
        




